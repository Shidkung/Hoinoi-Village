Hi there,

Thank for downloading our font Little Panda PERSONAL USE version. 

FOR COMMERCIAL USE :
https://www.creativefabrica.com/product/haunted-night/ref/237814/

Paypal account for donation : https://www.paypal.me/TeguhSubiyantoro

if you have any problem or question, please contact us by email to : subystudio.mdn@gmail.com

and follow us on instagram for update :  https://www.instagram.com/subystudio